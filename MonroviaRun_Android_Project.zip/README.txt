MONROVIA RUN — Android starter project
=====================================

This is an offline-first Android game project. It includes:
- Five selectable runners: O'Neal, Precious, Ovina, Tina, Francis
- Monrovia/Sinkor-inspired endless-runner route labels and scenery
- Three lanes, swipe controls, jump, slide, coins, obstacles and increasing speed
- Local high-score storage on the device
- No network permission and no online account required

IMPORTANT:
This is a first playable prototype, not yet a polished commercial 3D release.
The runner and city visuals are procedural 2D/3D-style artwork drawn by the game.
For photorealistic 3D characters, detailed landmark models, music, sound effects,
and a signed production APK, the project needs a further art/3D and build pass.

HOW TO BUILD THE APK:
1. Install Android Studio on a computer.
2. Open this folder as an existing Android Studio project.
3. Allow Android Studio to download the Android Gradle plugin and Android SDK.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK location.
6. Transfer the APK to an Android phone and install it. You may need to allow
   installation from that file manager.

Recommended test device: Android 8.0 or newer.
Package: com.monroviarun.game
Version: 1.0 prototype
